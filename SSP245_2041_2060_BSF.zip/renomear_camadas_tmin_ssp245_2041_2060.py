from qgis.core import QgsProject

# Padrão de nomes de meses
meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']

# Aplicar novo nome
layers = QgsProject.instance().mapLayers().values()
for layer in layers:
    for mes in meses:
        if mes in layer.name():
            layer.setName(f"Temperatura mínima (ºC)_{mes}")
            print(f"✅ Camada renomeada para: Temperatura mínima (ºC)_{mes}")
