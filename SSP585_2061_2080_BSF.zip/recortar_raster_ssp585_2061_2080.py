from qgis import processing
from qgis.core import QgsProject

# Definir entrada e saída
entrada_raster = 'CAMINHO/DO/RASTER_BRUTO.tif'  # Substituir pelo caminho real
mascara = 'CAMINHO/DO/SHAPEFILE_MASCARA.shp'    # Substituir pelo caminho real
saida_raster = 'E:/Projeto GeoBSF/Access/Tmin/2061 a 2080/SSP585/raster_recortado.tif'

# Executar recorte
processing.run("gdal:cliprasterbymasklayer", {
    'INPUT': entrada_raster,
    'MASK': mascara,
    'SOURCE_CRS': None,
    'TARGET_CRS': None,
    'NODATA': None,
    'CROP_TO_CUTLINE': True,
    'KEEP_RESOLUTION': True,
    'OUTPUT': saida_raster
})

print("✅ Recorte realizado com sucesso para SSP585 (2061-2080)!")
