import os
from qgis.core import QgsProject

# Caminho para salvar o projeto
caminho_projeto = r"E:/Projeto GeoBSF/Access/Tmin/2061 a 2080/SSP585/Tmin_SSP585_2061_2080.qgz"

# Garantir que o diretório exista
os.makedirs(os.path.dirname(caminho_projeto), exist_ok=True)

# Salvar o projeto
if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
