from qgis.core import (
    QgsProject, QgsLayoutItemLabel, QgsLayoutItemMap, QgsLayoutItemLegend,
    QgsPrintLayout, QgsLayoutExporter, QgsReadWriteContext
)
from qgis.PyQt.QtXml import QDomDocument
import os
import re

saida = r"E:/Projeto GeoBSF/Access/Tmin/2021 a 2040/SSP126/Layouts"
os.makedirs(saida, exist_ok=True)

meses = {
    "jan": "janeiro", "fev": "fevereiro", "mar": "março", "abr": "abril",
    "mai": "maio", "jun": "junho", "jul": "julho", "ago": "agosto",
    "set": "setembro", "out": "outubro", "nov": "novembro", "dez": "dezembro"
}

padrao = re.compile(r"^Temperatura mínima \(ºC\)_(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)$", re.IGNORECASE)

template_content = """<Layout units="mm" worldFileMap="{f4fa0291-2749-478f-beda-a816bb92682c}" printResolution="300" name="Teste 2">
 <Snapper snapToGuides="1" snapToGrid="0" snapToItems="1" tolerance="5"/>
 <Grid resUnits="mm" offsetUnits="mm" offsetY="0" resolution="10" offsetX="0"/>
 <PageCollection>
  <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
   <data_defined_properties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </data_defined_properties>
   <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="{c8037414-41f0-421d-aba0-623116d67984}">
    <Option type="Map">
     <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
     <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
     <Option type="QString" value="miter" name="joinstyle"/>
     <Option type="QString" value="0,0" name="offset"/>
     <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
     <Option type="QString" value="MM" name="offset_unit"/>
     <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
     <Option type="QString" value="no" name="outline_style"/>
     <Option type="QString" value="0.26" name="outline_width"/>
     <Option type="QString" value="MM" name="outline_width_unit"/>
     <Option type="QString" value="solid" name="style"/>
    </Option>
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
   </layer>
  </symbol>
  <LayoutItem frameJoinStyle="miter" positionOnPage="0,0,mm" size="297,210,mm" type="65638" outlineWidthM="0.3,mm" position="0,0,mm" visibility="1" opacity="1" itemRotation="0" referencePoint="0" background="true" excludeFromExports="0" zValue="0" uuid="{90058cb5-4bc3-4eb9-9342-8ee577ea764e}" templateUuid="{90058cb5-4bc3-4eb9-9342-8ee577ea764e}" frame="false" positionLock="false" groupUuid="" blendMode="0" id="">
   <FrameColor alpha="255" red="0" green="0" blue="0"/>
   <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
   <LayoutObject>
    <dataDefinedProperties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </dataDefinedProperties>
    <customproperties>
     <Option/>
    </customproperties>
   </LayoutObject>
   <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="{c26cae44-c7ab-45fd-8676-84dc337b9dec}">
     <Option type="Map">
      <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
      <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
      <Option type="QString" value="miter" name="joinstyle"/>
      <Option type="QString" value="0,0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
      <Option type="QString" value="no" name="outline_style"/>
      <Option type="QString" value="0.26" name="outline_width"/>
      <Option type="QString" value="MM" name="outline_width_unit"/>
      <Option type="QString" value="solid" name="style"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </LayoutItem>
  <GuideCollection visible="1"/>
 </PageCollection>
 <LayoutItem frameJoinStyle="miter" excludeFromExports="0" id="" zValue="6" symbolAlignment="1" title="" outlineWidthM="0.3,mm" wmsLegendHeight="25" maxSymbolSize="0" legendFilterByMap="1" columnCount="1" rasterBorder="1" wrapChar="" splitLayer="0" map_uuid="{f4fa0291-2749-478f-beda-a816bb92682c}" rasterBorderWidth="0" equalColumnWidth="0" positionLock="false" background="true" size="82.5614,30.8879,mm" type="65642" wmsLegendWidth="50" symbolHeight="4" templateUuid="{1a04bd61-ed95-4800-9ceb-c45999fe520c}" symbolWidth="7" frame="false" positionOnPage="195.342,177.127,mm" columnSpace="2" groupUuid="" referencePoint="0" rasterBorderColor="0,0,0,255,rgb:0,0,0,1" opacity="1" visibility="1" minSymbolSize="0" itemRotation="0" legendFilterByAtlas="0" uuid="{1a04bd61-ed95-4800-9ceb-c45999fe520c}" resizeToContents="1" titleAlignment="1" boxSpace="2" position="195.342,177.127,mm" blendMode="0">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
  <styles>
   <style indent="0" alignment="1" marginBottom="3.5" name="title">
    <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1.1000000000000001" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="16" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
     <families/>
     <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
     <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
     <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
      <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
       <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
        <Option type="Map">
         <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
         <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
         <Option type="QString" value="bevel" name="joinstyle"/>
         <Option type="QString" value="0,0" name="offset"/>
         <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
         <Option type="QString" value="MM" name="offset_unit"/>
         <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
         <Option type="QString" value="no" name="outline_style"/>
         <Option type="QString" value="0" name="outline_width"/>
         <Option type="QString" value="MM" name="outline_width_unit"/>
         <Option type="QString" value="solid" name="style"/>
        </Option>
        <data_defined_properties>
         <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
         </Option>
        </data_defined_properties>
       </layer>
      </symbol>
     </background>
     <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
     <dd_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </dd_properties>
    </text-style>
   </style>
   <style indent="0" alignment="1" name="group" marginTop="3">
    <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1.1000000000000001" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="14" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
     <families/>
     <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
     <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
     <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
      <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
       <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
        <Option type="Map">
         <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
         <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
         <Option type="QString" value="bevel" name="joinstyle"/>
         <Option type="QString" value="0,0" name="offset"/>
         <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
         <Option type="QString" value="MM" name="offset_unit"/>
         <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
         <Option type="QString" value="no" name="outline_style"/>
         <Option type="QString" value="0" name="outline_width"/>
         <Option type="QString" value="MM" name="outline_width_unit"/>
         <Option type="QString" value="solid" name="style"/>
        </Option>
        <data_defined_properties>
         <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
         </Option>
        </data_defined_properties>
       </layer>
      </symbol>
     </background>
     <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
     <dd_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </dd_properties>
    </text-style>
   </style>
   <style indent="0" alignment="1" name="subgroup" marginTop="3">
    <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1.1000000000000001" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="12" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
     <families/>
     <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
     <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
     <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
      <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
       <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
        <Option type="Map">
         <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
         <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
         <Option type="QString" value="bevel" name="joinstyle"/>
         <Option type="QString" value="0,0" name="offset"/>
         <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
         <Option type="QString" value="MM" name="offset_unit"/>
         <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
         <Option type="QString" value="no" name="outline_style"/>
         <Option type="QString" value="0" name="outline_width"/>
         <Option type="QString" value="MM" name="outline_width_unit"/>
         <Option type="QString" value="solid" name="style"/>
        </Option>
        <data_defined_properties>
         <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
         </Option>
        </data_defined_properties>
       </layer>
      </symbol>
     </background>
     <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
     <dd_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </dd_properties>
    </text-style>
   </style>
   <style indent="0" alignment="1" name="symbol" marginTop="2.5">
    <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="10" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
     <families/>
     <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
     <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
     <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
      <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
       <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
        <Option type="Map">
         <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
         <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
         <Option type="QString" value="bevel" name="joinstyle"/>
         <Option type="QString" value="0,0" name="offset"/>
         <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
         <Option type="QString" value="MM" name="offset_unit"/>
         <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
         <Option type="QString" value="no" name="outline_style"/>
         <Option type="QString" value="0" name="outline_width"/>
         <Option type="QString" value="MM" name="outline_width_unit"/>
         <Option type="QString" value="solid" name="style"/>
        </Option>
        <data_defined_properties>
         <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
         </Option>
        </data_defined_properties>
       </layer>
      </symbol>
     </background>
     <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
     <dd_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </dd_properties>
    </text-style>
   </style>
   <style indent="0" marginLeft="2" alignment="1" name="symbolLabel" marginTop="2">
    <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1.1000000000000001" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="12" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
     <families/>
     <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
     <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
     <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
      <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
       <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
        <Option type="Map">
         <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
         <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
         <Option type="QString" value="bevel" name="joinstyle"/>
         <Option type="QString" value="0,0" name="offset"/>
         <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
         <Option type="QString" value="MM" name="offset_unit"/>
         <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
         <Option type="QString" value="no" name="outline_style"/>
         <Option type="QString" value="0" name="outline_width"/>
         <Option type="QString" value="MM" name="outline_width_unit"/>
         <Option type="QString" value="solid" name="style"/>
        </Option>
        <data_defined_properties>
         <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
         </Option>
        </data_defined_properties>
       </layer>
      </symbol>
     </background>
     <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
     <dd_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </dd_properties>
    </text-style>
   </style>
  </styles>
 </LayoutItem>
 <LayoutItem frameJoinStyle="miter" positionOnPage="20.1128,191.903,mm" size="201.954,17.3576,mm" valign="32" labelText="Sistema de projeções: WGS 84&#xa;Conjunto de dados: CMIP6&#xa;Modelo: Access-CM2" type="65641" outlineWidthM="0.3,mm" position="20.1128,191.903,mm" visibility="1" marginY="0" htmlState="0" opacity="1" itemRotation="0" referencePoint="0" background="false" excludeFromExports="0" zValue="6" halign="1" uuid="{309a219b-ff86-4537-910d-6c9849c70aa4}" templateUuid="{309a219b-ff86-4537-910d-6c9849c70aa4}" frame="false" positionLock="false" groupUuid="" blendMode="0" id="" marginX="0">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
  <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="10" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
   <families/>
   <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
   <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
   <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
    <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
      <Option type="Map">
       <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
       <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="0,0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
       <Option type="QString" value="no" name="outline_style"/>
       <Option type="QString" value="0" name="outline_width"/>
       <Option type="QString" value="MM" name="outline_width_unit"/>
       <Option type="QString" value="solid" name="style"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </background>
   <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
   <dd_properties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dd_properties>
  </text-style>
 </LayoutItem>
 <LayoutItem segmentSizeMode="0" frameJoinStyle="miter" excludeFromExports="0" labelVerticalPlacement="0" id="" zValue="5" maxBarWidth="150" segmentMillimeters="14.3229" subdivisionsHeight="1.5" numSubdivisions="1" outlineWidthM="0.3,mm" lineJoinStyle="miter" unitLabel="km" style="Single Box" numMapUnitsPerScaleBarUnit="1" numSegments="2" positionLock="false" background="false" outlineWidth="0.3" labelHorizontalPlacement="0" size="41.9254,13.1955,mm" type="65646" templateUuid="{ec52e30f-6dd0-4242-bc70-2c5245146755}" frame="false" lineCapStyle="square" positionOnPage="22.0034,172.198,mm" unitType="km" groupUuid="" alignment="0" referencePoint="0" numUnitsPerSegment="25" labelBarSpace="3" opacity="1" visibility="1" itemRotation="0" minBarWidth="50" uuid="{ec52e30f-6dd0-4242-bc70-2c5245146755}" numSegmentsLeft="0" mapUuid="{f4fa0291-2749-478f-beda-a816bb92682c}" height="3" position="22.0034,172.198,mm" boxContentSpace="1" blendMode="0">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
  <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="12" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
   <families/>
   <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
   <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
   <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
    <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
      <Option type="Map">
       <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
       <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="0,0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
       <Option type="QString" value="no" name="outline_style"/>
       <Option type="QString" value="0" name="outline_width"/>
       <Option type="QString" value="MM" name="outline_width_unit"/>
       <Option type="QString" value="solid" name="style"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </background>
   <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
   <dd_properties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dd_properties>
  </text-style>
  <strokeColor alpha="255" red="0" green="0" blue="0"/>
  <numericFormat id="basic">
   <Option type="Map">
    <Option type="invalid" name="decimal_separator"/>
    <Option type="int" value="6" name="decimals"/>
    <Option type="int" value="0" name="rounding_type"/>
    <Option type="bool" value="false" name="show_plus"/>
    <Option type="bool" value="true" name="show_thousand_separator"/>
    <Option type="bool" value="false" name="show_trailing_zeros"/>
    <Option type="invalid" name="thousand_separator"/>
   </Option>
  </numericFormat>
  <fillColor alpha="255" red="0" green="0" blue="0"/>
  <fillColor2 alpha="255" red="255" green="255" blue="255"/>
  <lineSymbol>
   <symbol type="line" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleLine" locked="0" id="{4da4c510-777c-4ae4-bf66-0f4bc6d4acb8}">
     <Option type="Map">
      <Option type="QString" value="0" name="align_dash_pattern"/>
      <Option type="QString" value="square" name="capstyle"/>
      <Option type="QString" value="5;2" name="customdash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
      <Option type="QString" value="MM" name="customdash_unit"/>
      <Option type="QString" value="0" name="dash_pattern_offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
      <Option type="QString" value="0" name="draw_inside_polygon"/>
      <Option type="QString" value="miter" name="joinstyle"/>
      <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="line_color"/>
      <Option type="QString" value="solid" name="line_style"/>
      <Option type="QString" value="0.3" name="line_width"/>
      <Option type="QString" value="MM" name="line_width_unit"/>
      <Option type="QString" value="0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="0" name="ring_filter"/>
      <Option type="QString" value="0" name="trim_distance_end"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_end_unit"/>
      <Option type="QString" value="0" name="trim_distance_start"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_start_unit"/>
      <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
      <Option type="QString" value="0" name="use_custom_dash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </lineSymbol>
  <divisionLineSymbol>
   <symbol type="line" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleLine" locked="0" id="{4da4c510-777c-4ae4-bf66-0f4bc6d4acb8}">
     <Option type="Map">
      <Option type="QString" value="0" name="align_dash_pattern"/>
      <Option type="QString" value="square" name="capstyle"/>
      <Option type="QString" value="5;2" name="customdash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
      <Option type="QString" value="MM" name="customdash_unit"/>
      <Option type="QString" value="0" name="dash_pattern_offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
      <Option type="QString" value="0" name="draw_inside_polygon"/>
      <Option type="QString" value="miter" name="joinstyle"/>
      <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="line_color"/>
      <Option type="QString" value="solid" name="line_style"/>
      <Option type="QString" value="0.3" name="line_width"/>
      <Option type="QString" value="MM" name="line_width_unit"/>
      <Option type="QString" value="0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="0" name="ring_filter"/>
      <Option type="QString" value="0" name="trim_distance_end"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_end_unit"/>
      <Option type="QString" value="0" name="trim_distance_start"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_start_unit"/>
      <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
      <Option type="QString" value="0" name="use_custom_dash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </divisionLineSymbol>
  <subdivisionLineSymbol>
   <symbol type="line" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleLine" locked="0" id="{4da4c510-777c-4ae4-bf66-0f4bc6d4acb8}">
     <Option type="Map">
      <Option type="QString" value="0" name="align_dash_pattern"/>
      <Option type="QString" value="square" name="capstyle"/>
      <Option type="QString" value="5;2" name="customdash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
      <Option type="QString" value="MM" name="customdash_unit"/>
      <Option type="QString" value="0" name="dash_pattern_offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
      <Option type="QString" value="0" name="draw_inside_polygon"/>
      <Option type="QString" value="miter" name="joinstyle"/>
      <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="line_color"/>
      <Option type="QString" value="solid" name="line_style"/>
      <Option type="QString" value="0.3" name="line_width"/>
      <Option type="QString" value="MM" name="line_width_unit"/>
      <Option type="QString" value="0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="0" name="ring_filter"/>
      <Option type="QString" value="0" name="trim_distance_end"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_end_unit"/>
      <Option type="QString" value="0" name="trim_distance_start"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
      <Option type="QString" value="MM" name="trim_distance_start_unit"/>
      <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
      <Option type="QString" value="0" name="use_custom_dash"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </subdivisionLineSymbol>
  <fillSymbol1>
   <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="{bfed44e3-52a0-4d2c-9cf5-4b930f264b74}">
     <Option type="Map">
      <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
      <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="color"/>
      <Option type="QString" value="bevel" name="joinstyle"/>
      <Option type="QString" value="0,0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
      <Option type="QString" value="no" name="outline_style"/>
      <Option type="QString" value="0.26" name="outline_width"/>
      <Option type="QString" value="MM" name="outline_width_unit"/>
      <Option type="QString" value="solid" name="style"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </fillSymbol1>
  <fillSymbol2>
   <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
    <data_defined_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </data_defined_properties>
    <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="{ae3b04de-9df9-4915-b938-2b0818d87e5f}">
     <Option type="Map">
      <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
      <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
      <Option type="QString" value="bevel" name="joinstyle"/>
      <Option type="QString" value="0,0" name="offset"/>
      <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
      <Option type="QString" value="MM" name="offset_unit"/>
      <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
      <Option type="QString" value="no" name="outline_style"/>
      <Option type="QString" value="0.26" name="outline_width"/>
      <Option type="QString" value="MM" name="outline_width_unit"/>
      <Option type="QString" value="solid" name="style"/>
     </Option>
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
    </layer>
   </symbol>
  </fillSymbol2>
 </LayoutItem>
 <LayoutItem frameJoinStyle="miter" positionOnPage="278.272,5.63586,mm" size="14.0514,16.28,mm" file=":/images/north_arrows/layout_default_north_arrow.svg" pictureWidth="12.7232" svgFillColor="255,255,255,255,rgb:1,1,1,1" type="65640" outlineWidthM="0.3,mm" pictureRotation="-1" northOffset="0" position="278.272,5.63586,mm" visibility="1" opacity="1" svgBorderColor="0,0,0,255,rgb:0,0,0,1" svgBorderWidth="0.2" itemRotation="0" referencePoint="0" northMode="0" resizeMode="0" background="false" anchorPoint="0" excludeFromExports="0" zValue="3" uuid="{59b47a47-5f8d-4ded-9eec-6d5fef107354}" templateUuid="{59b47a47-5f8d-4ded-9eec-6d5fef107354}" mapUuid="{f4fa0291-2749-478f-beda-a816bb92682c}" frame="false" positionLock="false" groupUuid="" blendMode="0" pictureHeight="16.0604" id="Seta Norte" mode="2">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
 </LayoutItem>
 <LayoutItem frameJoinStyle="miter" positionOnPage="5.78586,5.78586,mm" size="254.027,24.7966,mm" valign="32" labelText="Temperatura máxima projetada para o mês de janeiro para o período entre 2021 a 2040 no cenário SSP245 para a região do Baixo São Francisco" type="65641" outlineWidthM="0.3,mm" position="5.78586,5.78586,mm" visibility="1" marginY="0" htmlState="0" opacity="1" itemRotation="0" referencePoint="0" background="false" excludeFromExports="0" zValue="2" halign="4" uuid="{d75b1ab9-7ecb-4ff1-aa56-c40352abe351}" templateUuid="{d75b1ab9-7ecb-4ff1-aa56-c40352abe351}" frame="true" positionLock="false" groupUuid="" blendMode="0" id="" marginX="0">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
  <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="Bold" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="75" fontWordSpacing="0" fontUnderline="0" fontSize="18" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
   <families/>
   <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
   <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
   <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
    <symbol type="marker" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="markerSymbol">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleMarker" locked="0" id="">
      <Option type="Map">
       <Option type="QString" value="0" name="angle"/>
       <Option type="QString" value="square" name="cap_style"/>
       <Option type="QString" value="231,113,72,255,rgb:0.90588235294117647,0.44313725490196076,0.28235294117647058,1" name="color"/>
       <Option type="QString" value="1" name="horizontal_anchor_point"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="circle" name="name"/>
       <Option type="QString" value="0,0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
       <Option type="QString" value="solid" name="outline_style"/>
       <Option type="QString" value="0" name="outline_width"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
       <Option type="QString" value="MM" name="outline_width_unit"/>
       <Option type="QString" value="diameter" name="scale_method"/>
       <Option type="QString" value="2" name="size"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
       <Option type="QString" value="MM" name="size_unit"/>
       <Option type="QString" value="1" name="vertical_anchor_point"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
    <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
      <Option type="Map">
       <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
       <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="0,0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
       <Option type="QString" value="no" name="outline_style"/>
       <Option type="QString" value="0" name="outline_width"/>
       <Option type="QString" value="MM" name="outline_width_unit"/>
       <Option type="QString" value="solid" name="style"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </background>
   <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
   <dd_properties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dd_properties>
  </text-style>
 </LayoutItem>
 <LayoutItem frameJoinStyle="miter" positionOnPage="24.1534,40.501,mm" size="231.363,122.881,mm" type="65639" outlineWidthM="0.3,mm" position="24.1534,40.501,mm" drawCanvasItems="true" visibility="1" isTemporal="0" keepLayerSet="false" opacity="1" itemRotation="0" referencePoint="0" followPresetName="" background="true" excludeFromExports="0" mapRotation="-1" zValue="1" uuid="{f4fa0291-2749-478f-beda-a816bb92682c}" templateUuid="{f4fa0291-2749-478f-beda-a816bb92682c}" mapFlags="0" followPreset="false" frame="false" positionLock="false" labelMargin="0,mm" groupUuid="" blendMode="0" id="Mapa 1">
  <FrameColor alpha="255" red="0" green="0" blue="0"/>
  <BackgroundColor alpha="255" red="255" green="255" blue="255"/>
  <LayoutObject>
   <dataDefinedProperties>
    <Option type="Map">
     <Option type="QString" value="" name="name"/>
     <Option name="properties"/>
     <Option type="QString" value="collection" name="type"/>
    </Option>
   </dataDefinedProperties>
   <customproperties>
    <Option/>
   </customproperties>
  </LayoutObject>
  <Extent ymin="-10.7758431453375092" xmin="-38.98038542057252442" xmax="-35.28797677442756964" ymax="-8.81474622066242297"/>
  <LayerSet/>
  <ComposerMapGrid topAnnotationDisplay="0" leftFrameDivisions="0" bottomAnnotationDirection="0" rotatedTicksMarginToCorner="0" frameFillColor1="255,255,255,255,rgb:1,1,1,1" gridFrameMargin="0" rotatedTicksEnabled="0" rotatedAnnotationsEnabled="0" topAnnotationDirection="0" leftAnnotationDisplay="0" offsetX="0" gridStyle="1" minimumIntervalWidth="50" annotationFormat="4" bottomFrameDivisions="0" rightFrameDivisions="0" show="1" offsetY="0" showAnnotation="1" intervalX="0.5" maximumIntervalWidth="100" rotatedAnnotationsMinimumAngle="0" gridFrameWidth="2" leftAnnotationDirection="0" crossLength="3" topAnnotationPosition="1" gridFramePenColor="0,0,0,255,rgb:0,0,0,1" rotatedTicksLengthMode="0" rightAnnotationDirection="0" rightAnnotationPosition="1" frameFillColor2="0,0,0,255,rgb:0,0,0,1" gridFramePenThickness="0.29999999999999999" gridFrameStyle="7" rotatedTicksMinimumAngle="0" frameAnnotationDistance="1" gridFrameSideFlags="15" annotationExpression="" topFrameDivisions="0" bottomAnnotationPosition="1" rotatedAnnotationsMarginToCorner="0" rightAnnotationDisplay="0" bottomAnnotationDisplay="0" rotatedAnnotationsLengthMode="0" uuid="{82c8bad8-e966-4449-88c9-cbb1d941cd4a}" annotationPrecision="3" intervalY="0.5" name="Grade 1" leftAnnotationPosition="1" position="3" unit="0" blendMode="0">
   <lineStyle>
    <symbol type="line" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleLine" locked="0" id="{4d16ec26-987a-414e-8927-ea59b3464fb1}">
      <Option type="Map">
       <Option type="QString" value="0" name="align_dash_pattern"/>
       <Option type="QString" value="flat" name="capstyle"/>
       <Option type="QString" value="5;2" name="customdash"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
       <Option type="QString" value="MM" name="customdash_unit"/>
       <Option type="QString" value="0" name="dash_pattern_offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
       <Option type="QString" value="0" name="draw_inside_polygon"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="line_color"/>
       <Option type="QString" value="solid" name="line_style"/>
       <Option type="QString" value="0.3" name="line_width"/>
       <Option type="QString" value="MM" name="line_width_unit"/>
       <Option type="QString" value="0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="0" name="ring_filter"/>
       <Option type="QString" value="0" name="trim_distance_end"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
       <Option type="QString" value="MM" name="trim_distance_end_unit"/>
       <Option type="QString" value="0" name="trim_distance_start"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
       <Option type="QString" value="MM" name="trim_distance_start_unit"/>
       <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
       <Option type="QString" value="0" name="use_custom_dash"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </lineStyle>
   <markerStyle>
    <symbol type="marker" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="">
     <data_defined_properties>
      <Option type="Map">
       <Option type="QString" value="" name="name"/>
       <Option name="properties"/>
       <Option type="QString" value="collection" name="type"/>
      </Option>
     </data_defined_properties>
     <layer enabled="1" pass="0" class="SimpleMarker" locked="0" id="{788c7b11-1ac9-4b25-8c55-2a49a541f068}">
      <Option type="Map">
       <Option type="QString" value="0" name="angle"/>
       <Option type="QString" value="square" name="cap_style"/>
       <Option type="QString" value="0,0,0,255,rgb:0,0,0,1" name="color"/>
       <Option type="QString" value="1" name="horizontal_anchor_point"/>
       <Option type="QString" value="bevel" name="joinstyle"/>
       <Option type="QString" value="circle" name="name"/>
       <Option type="QString" value="0,0" name="offset"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
       <Option type="QString" value="MM" name="offset_unit"/>
       <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
       <Option type="QString" value="solid" name="outline_style"/>
       <Option type="QString" value="0" name="outline_width"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
       <Option type="QString" value="MM" name="outline_width_unit"/>
       <Option type="QString" value="diameter" name="scale_method"/>
       <Option type="QString" value="2" name="size"/>
       <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
       <Option type="QString" value="MM" name="size_unit"/>
       <Option type="QString" value="1" name="vertical_anchor_point"/>
      </Option>
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
     </layer>
    </symbol>
   </markerStyle>
   <text-style forcedItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" textOpacity="1" fontFamily="MS Shell Dlg 2" fontWeight="50" fontWordSpacing="0" fontUnderline="0" fontSize="10" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" capitalization="0" fontKerning="1" fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" textOrientation="horizontal" blendMode="0" fontItalic="0" allowHtml="0">
    <families/>
    <text-buffer bufferOpacity="1" bufferDraw="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferNoFill="1" bufferSizeUnits="MM" bufferBlendMode="0"/>
    <text-mask maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
    <background shapeRadiiY="0" shapeBlendMode="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeOffsetY="0" shapeDraw="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeSizeY="0" shapeRadiiUnit="MM" shapeSizeType="0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeJoinStyle="64" shapeRotation="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeUnit="MM">
     <symbol type="fill" alpha="1" clip_to_extent="1" frame_rate="10" force_rhr="0" is_animated="0" name="fillSymbol">
      <data_defined_properties>
       <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
       </Option>
      </data_defined_properties>
      <layer enabled="1" pass="0" class="SimpleFill" locked="0" id="">
       <Option type="Map">
        <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
        <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
        <Option type="QString" value="bevel" name="joinstyle"/>
        <Option type="QString" value="0,0" name="offset"/>
        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
        <Option type="QString" value="MM" name="offset_unit"/>
        <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
        <Option type="QString" value="no" name="outline_style"/>
        <Option type="QString" value="0" name="outline_width"/>
        <Option type="QString" value="MM" name="outline_width_unit"/>
        <Option type="QString" value="solid" name="style"/>
       </Option>
       <data_defined_properties>
        <Option type="Map">
         <Option type="QString" value="" name="name"/>
         <Option name="properties"/>
         <Option type="QString" value="collection" name="type"/>
        </Option>
       </data_defined_properties>
      </layer>
     </symbol>
    </background>
    <shadow shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowUnder="0" shadowOpacity="0.69999999999999996" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0"/>
    <dd_properties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </dd_properties>
   </text-style>
   <LayoutObject>
    <dataDefinedProperties>
     <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
     </Option>
    </dataDefinedProperties>
    <customproperties>
     <Option/>
    </customproperties>
   </LayoutObject>
  </ComposerMapGrid>
  <AtlasMap margin="0.10000000000000001" scalingMode="2" atlasDriven="0"/>
  <labelBlockingItems/>
  <atlasClippingSettings enabled="0" restrictLayers="0" clippingType="1" forceLabelsInside="0">
   <layersToClip/>
  </atlasClippingSettings>
  <itemClippingSettings enabled="0" clipSource="" clippingType="1" forceLabelsInside="0"/>
 </LayoutItem>
 <customproperties>
  <Option type="Map">
   <Option type="QString" value="png" name="atlasRasterFormat"/>
   <Option type="bool" value="true" name="singleFile"/>
  </Option>
 </customproperties>
 <Atlas enabled="0" sortFeatures="0" hideCoverage="0" filterFeatures="0" coverageLayer="" filenamePattern="'output_'||@atlas_featurenumber" pageNameExpression=""/>
</Layout>
"""

projeto = QgsProject.instance()
manager = projeto.layoutManager()

print("📌 Camadas encontradas no projeto:")
for lyr in projeto.mapLayers().values():
    print(" -", lyr.name())

for layer in projeto.mapLayers().values():
    if layer.type() != layer.RasterLayer:
        continue

    nome = layer.name()
    match = padrao.match(nome)
    if not match:
        continue

    mes = match.group(1).lower()
    mes_ext = meses[mes]
    nome_layout = f"Tmin_{mes}_2021_2040_SSP126"

    print(f"🧭 Criando layout: {nome_layout}")

    template_modificado = (
        template_content
        .replace("janeiro", mes_ext)
        .replace("Temperatura máxima", "Temperatura mínima")
        .replace("SSP245", "SSP126")
        .replace("SSP585", "SSP126")
    )

    doc = QDomDocument()
    if not doc.setContent(template_modificado):
        print("❌ Erro ao carregar XML.")
        continue

    layout = QgsPrintLayout(projeto)
    layout.initializeDefaults()
    layout.setName(nome_layout)
    context = QgsReadWriteContext()

    if not layout.readXml(doc.documentElement(), doc, context):
        print("❌ Erro ao carregar layout.")
        continue

    if not layout.items():
        print(f"⚠️ Layout '{nome_layout}' criado, mas está vazio.")
        continue

    for item in layout.items():
        if isinstance(item, QgsLayoutItemMap):
            item.setLayers([layer])
            item.zoomToExtent(layer.extent())
        elif isinstance(item, QgsLayoutItemLegend):
            item.model().rootGroup().clear()
            item.model().rootGroup().addLayer(layer)
            item.updateLegend()
        elif isinstance(item, QgsLayoutItemLabel):
            texto = item.text()
            if any(p in texto for p in ["janeiro", "Temperatura máxima", "SSP245", "SSP585"]):
                novo_texto = (
                    texto.replace("janeiro", mes_ext)
                         .replace("Temperatura máxima", "Temperatura mínima")
                         .replace("SSP245", "SSP126")
                         .replace("SSP585", "SSP126")
                )
                item.setText(novo_texto)

    caminho_png = os.path.join(saida, f"{nome_layout}.png")
    exportador = QgsLayoutExporter(layout)
    status = exportador.exportToImage(caminho_png, QgsLayoutExporter.ImageExportSettings())

    if status == QgsLayoutExporter.Success:
        print(f"✅ PNG exportado: {caminho_png}")
    else:
        print(f"❌ Falha ao exportar PNG de: {nome_layout}")

    caminho_qpt = os.path.join(saida, f"{nome_layout}.qpt")
    doc_final = QDomDocument()
    layout.writeXml(doc_final, context)
    with open(caminho_qpt, 'w', encoding='utf-8') as f:
        f.write(doc_final.toString())
    print(f"📝 Modelo QPT salvo: {caminho_qpt}")

    manager.addLayout(layout)

print("\n🏁 Processo concluído com sucesso para Temperatura mínima – SSP126.")
