from qgis import processing
from qgis.core import QgsProject

entrada_raster = 'CAMINHO/DO/RASTER_BRUTO.tif'
mascara = 'CAMINHO/DO/SHAPEFILE_MASCARA.shp'
saida_raster = 'E:/Projeto GeoBSF/Access/Tmin/2081 a 2100/SSP370/raster_recortado.tif'

processing.run("gdal:cliprasterbymasklayer", {
    'INPUT': entrada_raster,
    'MASK': mascara,
    'SOURCE_CRS': None,
    'TARGET_CRS': None,
    'NODATA': None,
    'CROP_TO_CUTLINE': True,
    'KEEP_RESOLUTION': True,
    'OUTPUT': saida_raster
})

print("✅ Recorte realizado com sucesso para SSP370 (2081-2100)!")
