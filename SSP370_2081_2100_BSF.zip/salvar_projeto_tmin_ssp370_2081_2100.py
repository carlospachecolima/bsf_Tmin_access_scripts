import os
from qgis.core import QgsProject

caminho_projeto = r"E:/Projeto GeoBSF/Access/Tmin/2081 a 2100/SSP370/Tmin_SSP370_2081_2100.qgz"

os.makedirs(os.path.dirname(caminho_projeto), exist_ok=True)

if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
