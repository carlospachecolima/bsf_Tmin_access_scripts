from qgis.core import (
    QgsProject, QgsLayoutItemLabel, QgsLayoutItemMap,
    QgsPrintLayout, QgsLayoutExporter, QgsReadWriteContext, QgsRasterLayer
)
from qgis.PyQt.QtXml import QDomDocument
import os
import re

# Diretório de saída
saida = r"E:/Projeto GeoBSF/Access/Tmin/Historico/Layouts"
os.makedirs(saida, exist_ok=True)

# Lista de meses
meses = {
    "jan": "janeiro", "fev": "fevereiro", "mar": "março", "abr": "abril",
    "mai": "maio", "jun": "junho", "jul": "julho", "ago": "agosto",
    "set": "setembro", "out": "outubro", "nov": "novembro", "dez": "dezembro"
}

# Expressão regular para nomes das camadas
padrao = re.compile(r"^Temperatura mínima histórica \(ºC\)_(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)$", re.IGNORECASE)

# Caminho do template .qpt
template_path = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP245/Modelo Tmax BSF.qpt"

# Carregar o modelo de layout
with open(template_path, 'r', encoding='utf-8') as f:
    template_content = f.read()

# Lista de todas as camadas raster válidas
layers = [layer for layer in QgsProject.instance().mapLayers().values() if isinstance(layer, QgsRasterLayer) and padrao.match(layer.name())]

# Para cada camada
for layer in layers:
    nome = layer.name()
    mes_abrev = padrao.match(nome).group(1)
    mes_extenso = meses[mes_abrev]

    print(f"🗺️ Gerando layout para: {nome}")

    # Criar novo layout
    project = QgsProject.instance()
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    document = QDomDocument()
    document.setContent(template_content)
    layout.readLayoutXml(document.documentElement(), document, QgsReadWriteContext())  # <-- Correção
    layout.setName(f"Layout_{mes_extenso}")

    # Atualizar o título
    for item in layout.items():
        if isinstance(item, QgsLayoutItemLabel) and "Temperatura máxima projetada" in item.text():
            novo_titulo = f"Temperatura histórica (1970 a 2000) mínima do mês de {mes_extenso} na região do Baixo São Francisco"
            item.setText(novo_titulo)
            item.refresh()

    # Atualizar o mapa principal
    for item in layout.items():
        if isinstance(item, QgsLayoutItemMap):
            item.setLayers([layer])
            item.zoomToExtent(layer.extent())
            item.refresh()

    # Adicionar o layout ao projeto
    manager = project.layoutManager()
    manager.addLayout(layout)

    # Exportar o layout
    caminho_saida = os.path.join(saida, f"Temperatura_minima_historica_{mes_extenso}.png")
    exporter = QgsLayoutExporter(layout)
    settings = QgsLayoutExporter.ImageExportSettings()
    result = exporter.exportToImage(caminho_saida, settings)

    if result == QgsLayoutExporter.Success:
        print(f"✅ Layout exportado: {caminho_saida}")
    else:
        print(f"⚠️ Erro ao exportar o layout para: {caminho_saida}")

    # Remover a camada após exportar
    QgsProject.instance().removeMapLayer(layer)

print("🎯 Todos os layouts históricos foram gerados com sucesso.")
