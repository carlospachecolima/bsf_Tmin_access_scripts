from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa típica atualizada para Tmin Histórico (ºC)
min_temp = 14.0
max_temp = 25.0

# Paleta adaptada para faixa de 14°C a 25°C
cores_tmin_historico = [
    (14.0, QColor("#0000ff")),  # Azul
    (16.0, QColor("#005fff")),  # Azul claro
    (18.0, QColor("#00bfff")),  # Ciano
    (20.0, QColor("#00ffff")),  # Verde-água
    (22.0, QColor("#80ff80")),  # Verde claro
    (24.0, QColor("#ffff00")),  # Amarelo
    (25.0, QColor("#ff9900"))   # Laranja
]

# Aplicar simbologia apenas às camadas de Temperatura mínima histórica
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer and "temperatura mínima histórica" in layer.name().lower():
        print(f"🎨 Estilizando: {layer.name()}")

        shader_items = []
        for valor, cor in cores_tmin_historico:
            shader_items.append(QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.1f} °C"))

        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_temp)
        shader.setMaximumValue(max_temp)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Temperatura mínima histórica.")

# --- Salvar o projeto após estilizar ---
caminho_projeto = "E:/Projeto GeoBSF/Access/Tmin/Historico/Tmin_Historico.qgz"
if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
