from qgis.core import QgsProject, QgsRasterFileWriter

import os

# Lista dos meses abreviados
meses_abrev = [
    "jan", "fev", "mar", "abr", "mai", "jun",
    "jul", "ago", "set", "out", "nov", "dez"
]

# Diretório de saída
diretorio_saida = "E:/Projeto GeoBSF/Access/Tmin/Historico"

# Garante que o diretório exista
if not os.path.exists(diretorio_saida):
    os.makedirs(diretorio_saida)

# Renomear e salvar as camadas raster carregadas
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() != layer.RasterLayer:
        continue

    nome_original = layer.name().lower().strip()

    for mes in meses_abrev:
        if mes in nome_original and not nome_original.startswith("temperatura mínima histórica"):
            novo_nome = f"Temperatura mínima histórica (ºC)_{mes}"
            layer.setName(novo_nome)
            print(f"🔄 Renomeado: {nome_original} → {novo_nome}")

            # Caminho completo para salvar o raster
            caminho_saida = os.path.join(diretorio_saida, f"{novo_nome}.tif")

            # Salvar o raster
            error = QgsRasterFileWriter.writeRaster(
                layer.dataProvider(),
                caminho_saida,
                layer.width(),
                layer.height(),
                layer.extent(),
                layer.crs()
            )

            if error == QgsRasterFileWriter.NoError:
                print(f"✅ Salvo: {caminho_saida}")
            else:
                print(f"⚠️ Erro ao salvar: {caminho_saida}")

            break
    else:
        print(f"⏭️ Ignorado: {nome_original}")
