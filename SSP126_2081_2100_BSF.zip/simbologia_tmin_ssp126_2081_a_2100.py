from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa para Tmin SSP126 (ºC)
min_temp = 14.0
max_temp = 26.0

# Paleta de cores
cores_tmin = [
    (14.0, QColor("#0000ff")),
    (16.0, QColor("#005fff")),
    (18.0, QColor("#00bfff")),
    (20.0, QColor("#00ffff")),
    (22.0, QColor("#80ff80")),
    (24.0, QColor("#ffff00")),
    (26.0, QColor("#ff9900"))
]

for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.1f} °C") for valor, cor in cores_tmin]
        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_temp)
        shader.setMaximumValue(max_temp)
        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)
        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Temperatura mínima – SSP126 (2081-2100).")
