from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa atualizada para Tmin SSP126 (ºC)
min_temp = 14.0
max_temp = 26.0

# Paleta estilizada para temperatura mínima (14 a 26°C)
cores_tmin = [
    (14.0, QColor("#0000ff")),   # Azul escuro
    (16.0, QColor("#005fff")),   # Azul claro
    (18.0, QColor("#00bfff")),   # Ciano
    (20.0, QColor("#00ffff")),   # Verde-água
    (22.0, QColor("#80ff80")),   # Verde claro
    (24.0, QColor("#ffff00")),   # Amarelo
    (26.0, QColor("#ff9900"))    # Laranja forte
]

# Aplicar simbologia a todas as camadas raster
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")

        shader_items = []
        for valor, cor in cores_tmin:
            shader_items.append(QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.1f} °C"))

        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_temp)
        shader.setMaximumValue(max_temp)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Temperatura mínima – SSP126 (2041-2060).")
