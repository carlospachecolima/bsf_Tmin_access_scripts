from qgis.core import (
    QgsProject, QgsLayoutItemLabel, QgsLayoutItemMap,
    QgsPrintLayout, QgsLayoutExporter, QgsReadWriteContext, QgsRasterLayer
)
from qgis.PyQt.QtXml import QDomDocument
import os
import re

# Diretório de saída
saida = r"E:/Projeto GeoBSF/Access/Tmin/2041 a 2060/SSP126/Layouts"
os.makedirs(saida, exist_ok=True)

# Lista de meses
meses = {
    "jan": "janeiro", "fev": "fevereiro", "mar": "março", "abr": "abril",
    "mai": "maio", "jun": "junho", "jul": "julho", "ago": "agosto",
    "set": "setembro", "out": "outubro", "nov": "novembro", "dez": "dezembro"
}

# Expressão regular
padrao = re.compile(r"^Temperatura mínima \(ºC\)_(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)$", re.IGNORECASE)

# Template do layout
template_path = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP245/Modelo Tmax BSF.qpt"

with open(template_path, 'r', encoding='utf-8') as f:
    template_content = f.read()

for layer in QgsProject.instance().mapLayers().values():
    if isinstance(layer, QgsRasterLayer) and padrao.match(layer.name()):
        nome = layer.name()
        mes_abrev = padrao.match(nome).group(1)
        mes_extenso = meses[mes_abrev]

        project = QgsProject.instance()
        layout = QgsPrintLayout(project)
        layout.initializeDefaults()
        document = QDomDocument()
        document.setContent(template_content)
        layout.readLayoutXml(document.documentElement(), document, QgsReadWriteContext())
        layout.setName(f"Layout_{mes_extenso}")

        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel) and "Temperatura máxima projetada" in item.text():
                item.setText(f"Temperatura mínima projetada (2041 a 2060) – SSP126 – mês de {mes_extenso} – Região do Baixo São Francisco")
                item.refresh()

        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                item.setLayers([layer])
                item.zoomToExtent(layer.extent())
                item.refresh()

        caminho_saida = os.path.join(saida, f"Tmin_SSP126_2041_2060_{mes_extenso}.png")
        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.ImageExportSettings()
        exporter.exportToImage(caminho_saida, settings)

        QgsProject.instance().removeMapLayer(layer)

print("🎯 Exportação de todas as imagens concluída com sucesso.")
