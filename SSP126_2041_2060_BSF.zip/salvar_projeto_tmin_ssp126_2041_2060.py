import os
from qgis.core import QgsProject

# Caminho para salvar o projeto
caminho_projeto = r"E:/Projeto GeoBSF/Access/Tmin/2041 a 2060/SSP126/Tmin_SSP126_2041_2060.qgz"

# Garantir que o diretório exista
os.makedirs(os.path.dirname(caminho_projeto), exist_ok=True)

# Salvar o projeto
if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")
